(function () {
  const t = document.createElement("link").relList;
  if (t && t.supports && t.supports("modulepreload")) return;
  for (const r of document.querySelectorAll('link[rel="modulepreload"]')) n(r);
  new MutationObserver((r) => {
    for (const s of r)
      if (s.type === "childList")
        for (const d of s.addedNodes)
          d.tagName === "LINK" && d.rel === "modulepreload" && n(d);
  }).observe(document, { childList: !0, subtree: !0 });
  function o(r) {
    const s = {};
    return (
      r.integrity && (s.integrity = r.integrity),
      r.referrerPolicy && (s.referrerPolicy = r.referrerPolicy),
      r.crossOrigin === "use-credentials"
        ? (s.credentials = "include")
        : r.crossOrigin === "anonymous"
        ? (s.credentials = "omit")
        : (s.credentials = "same-origin"),
      s
    );
  }
  function n(r) {
    if (r.ep) return;
    r.ep = !0;
    const s = o(r);
    fetch(r.href, s);
  }
})();
const a = document.querySelector(".header");
window.addEventListener("scroll", () => {
  window.scrollY > 50
    ? ((a.style.padding = "10px 0"),
      (a.style.backgroundColor = "rgba(73, 198, 23, 0)"))
    : ((a.style.padding = "15px 0"),
      (a.style.backgroundColor = "rgba(73, 198, 23, 0)"));
});
const l = document.querySelectorAll(".testimonial-slide"),
  m = document.querySelectorAll(".dot"),
  y = document.querySelector(".prev-btn"),
  p = document.querySelector(".next-btn");
let c = 0;
function f(e) {
  l.forEach((t) => {
    t.classList.remove("active");
  }),
    m.forEach((t) => {
      t.classList.remove("active");
    }),
    l[e].classList.add("active"),
    m[e].classList.add("active");
}
function u() {
  (c = (c + 1) % l.length), f(c);
}
function g() {
  (c = (c - 1 + l.length) % l.length), f(c);
}
if (y && p) {
  y.addEventListener("click", g), p.addEventListener("click", u);
  let e = setInterval(u, 5e3);
  const t = document.querySelector(".testimonial-slider");
  t.addEventListener("mouseenter", () => {
    clearInterval(e);
  }),
    t.addEventListener("mouseleave", () => {
      e = setInterval(u, 5e3);
    }),
    m.forEach((o, n) => {
      o.addEventListener("click", () => {
        (c = n), f(c);
      });
    });
}
const L = document.querySelectorAll(".faq-item");
L.forEach((e) => {
  e.querySelector(".faq-question").addEventListener("click", () => {
    e.classList.toggle("active");
    const o = e.querySelector(".faq-toggle i");
    e.classList.contains("active")
      ? (o.classList.remove("fa-plus"), o.classList.add("fa-minus"))
      : (o.classList.remove("fa-minus"), o.classList.add("fa-plus"));
  });
});
document.querySelectorAll('a[href^="#"]').forEach((e) => {
  e.addEventListener("click", function (t) {
    t.preventDefault();
    const o = this.getAttribute("href"),
      n = document.querySelector(o);
    n && window.scrollTo({ top: n.offsetTop - 80, behavior: "smooth" });
  });
});
const i = document.querySelector(".contact-form");
i &&
  i.addEventListener("submit", (e) => {
    e.preventDefault();
    const t = i.querySelector('input[type="text"]').value,
      o = i.querySelector('input[type="email"]').value,
      n = i.querySelector("select").value;
    console.log("Form submitted:", { name: t, email: o, industry: n }),
      (i.innerHTML = `
      <div class="success-message">
        <i class="fas fa-check-circle" style="font-size: 3rem; color: var(--primary-color); margin-bottom: 20px;"></i>
        <h3>Thank you for your interest!</h3>
        <p>We'll be in touch with you shortly to discuss how NVIDIA AI-Powered Smart Edge can transform your IoT infrastructure.</p>
      </div>
    `);
  });
const v = () => {
  document
    .querySelectorAll(".step, .industry-card, .benefit-card")
    .forEach((t) => {
      const o = t.getBoundingClientRect().top,
        n = window.innerHeight / 1.3;
      o < n && ((t.style.opacity = "1"), (t.style.transform = "translateY(0)"));
    });
};
document
  .querySelectorAll(".step, .industry-card, .benefit-card")
  .forEach((e) => {
    (e.style.opacity = "0"),
      (e.style.transform = "translateY(20px)"),
      (e.style.transition = "opacity 0.5s ease, transform 0.5s ease");
  });
window.addEventListener("scroll", v);
window.addEventListener("load", v);
function h() {
  const o = (Math.random() * 15 + 20).toFixed(1);
  document.getElementById("temperature").innerText = o + "°C";
}
setInterval(h, 3e3);
h();
window.fetchImage = function () {
  const e = new Date().toLocaleTimeString();
  document.getElementById(
    "ai-image"
  ).src = `https://placehold.co/400x300/2a2a2a/FFFFFF?text=AI+Image+${e}`;
};
fetchImage();
